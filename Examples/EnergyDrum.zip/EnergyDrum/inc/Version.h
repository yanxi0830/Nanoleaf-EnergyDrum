/*
 * Version.h
 *
 *  Created on: Mar 9, 2017
 *      Author: eski
 */

#ifndef INC_VERSION_H_
#define INC_VERSION_H_


#define SDK_VERSION "2.0"


#endif /* INC_VERSION_H_ */
